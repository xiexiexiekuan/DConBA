#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int findCharCount(string str)
{
	int num=0;
	char* strchar = (char*)str.data();
	for (int i=0;i<str.length();++i)
	{
		if (strchar[i]==',')
		{
			++num;//如果为逗号，num加1
		}
	}
    //cout<<strchar<<"      "<<num<<endl;
	strchar=NULL;
	return num;
}

int main(int argc, char **argv)
{
    //cout<<"预测网络："<<endl;
    ifstream myfile(argv[2]);
    if(!myfile.is_open())
    {
        cout<<argv[2]<<"文件打开失败"<<endl;
        return 0;
    }
    string temp;
    int N;
    myfile>>N;
    getline(myfile,temp);
    int matrix[N][N];
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            matrix[i][j]=0;
    //cout<<N<<endl;
    int mycount[N];
    for(int i=0;i<N;i++)
    {
        getline(myfile,temp);
        //cout<<temp<<endl;
        int times=findCharCount(temp);
        mycount[i]=times;
        //cout<<times<<endl;
    }
    myfile.seekg(0,ios::beg);
    myfile>>N;
    //for(int i=0;i<N;i++)cout<<mycount[i]<<endl;
    for(int i=0;i<N;i++)
    {
        getline(myfile,temp,'[');
        int child=i,times=mycount[i];
        //myfile>>child;
        //getline(myfile,temp,'=');
        //myfile>>times;
        int father[times];
        
        getline(myfile,temp,'{');
        //if(times==0)cout<<child<<" "<<"null"<<endl;
        for(int j=0;j<times;j++)
        {
            myfile>>father[j];
            //cout<<child<<" "<<father[j]<<endl;
            matrix[father[j]][child]++;
            getline(myfile,temp,' ');
        }
        getline(myfile,temp);
    }
    myfile.close();

    // for(int i=0;i<N;i++)
    // {
    //     for(int j=0;j<N;j++)
    //     {
    //         cout<<matrix[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }


    //cout<<endl<<"标准网络："<<endl;
    //string graph(argv[2]);
//cout<<graph<<endl;
    ifstream yourfile(argv[1]);
     if(!yourfile.is_open())
    {
        cout<<argv[1]<<"文件打开失败"<<endl;
        return 0;
    }
    int standard[N][N];
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            standard[i][j]=0;
    int num;

    for(int i=0;i<N;i++)
    {
        for(int j=0;j<N;j++)
        {
            yourfile>>num;
            standard[i][j]=num;
        }
    }
    yourfile.close();
    // for(int i=0;i<N;i++)
    // {
    //     for(int j=0;j<N;j++)
    //     {
    //         cout<<standard[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }


    //cout<<endl<<"混淆矩阵："<<endl;
    int hxjz[2][2]={{0,0},{0,0}};
    /*
    标准有的，你也有        标准有的，你没有
    标准没有，你却有        标准有的，你也有
    */
    for(int i=0;i<N;i++)
    {
        for(int j=0;j<N;j++)
        {
            if(standard[i][j]==1)
            {
                if(matrix[i][j]==1)hxjz[0][0]++;
                else hxjz[0][1]++;
            }else
                if(matrix[i][j]==1)hxjz[1][0]++;
                else hxjz[1][1]++;
        }
    }
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            cout<<hxjz[i][j]<<"  ";
        }
        cout<<endl<<endl;
    }
    float acc=(hxjz[0][0]+hxjz[1][1])*1.0/(hxjz[0][0]+hxjz[1][1]+hxjz[0][1]+hxjz[1][0])*1.0;
    float pre=hxjz[0][0]*1.0/(hxjz[0][0]+hxjz[1][0])*1.0;
    float recall=hxjz[0][0]*1.0/(hxjz[0][0]+hxjz[0][1])*1.0;
    float f1=2.0*pre*recall/(pre+recall);
    cout<<"acc = "<<acc<<'\t';
    cout<<"pre = "<<pre<<'\t';
    cout<<"rec = "<<recall<<'\t';
    cout<<"f1 = "<<f1<<endl;
    return 0;
}