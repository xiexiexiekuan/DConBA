编译：gcc Cmatrix.cpp -lstdc++ -o Cmatrix
运行：./Cmatrix Childgraph.txt wl.txt
                标准文件       预测文件
